import time

# 1. Configuración de las reglas de seguridad
UMBRAL_CONFIANZA = 0.95 
TIEMPO_ALERTA_SEGUNDOS = 15 

# Variables para controlar el estado del temporizador
estado_peligro_actual = None
tiempo_inicio_peligro = None
alerta_enviada = False

def evaluar_predicciones(predicciones, continuar_temporizador=True):
    global estado_peligro_actual, tiempo_inicio_peligro, alerta_enviada

    postura_peligrosa_detectada = None

    # Verificar si alguna clase de peligro supera la probabilidad del 95%
    for clase, confianza in predicciones.items():
        if clase in ["Caida_Inmovilidad", "Cama_Peligro"] and confianza > UMBRAL_CONFIANZA:
            postura_peligrosa_detectada = clase
            break

    if not continuar_temporizador:
        return {
            "postura_peligrosa": postura_peligrosa_detectada,
            "segundos": 0,
            "alerta_enviada": False,
            "umbral_confianza": UMBRAL_CONFIANZA,
            "tiempo_alerta_segundos": TIEMPO_ALERTA_SEGUNDOS,
        }

    # 2. Lógica del temporizador
    if postura_peligrosa_detectada:
        # Si recién detecta el peligro, inicia el conteo
        if estado_peligro_actual != postura_peligrosa_detectada:
            estado_peligro_actual = postura_peligrosa_detectada
            tiempo_inicio_peligro = time.time()
            alerta_enviada = False
            print(f"[{postura_peligrosa_detectada}] detectada. Iniciando temporizador...")

        # Calcular segundos continuos en la postura
        tiempo_transcurrido = time.time() - tiempo_inicio_peligro

        # Disparar la alerta si supera el tiempo establecido
        if tiempo_transcurrido >= TIEMPO_ALERTA_SEGUNDOS and not alerta_enviada:
            disparar_alerta_medica(postura_peligrosa_detectada)
            alerta_enviada = True
    else:
        tiempo_transcurrido = 0
        # Si la confianza baja del 95% o la persona se mueve, se reinicia el sistema
        if estado_peligro_actual is not None:
            print("Postura normalizada o confianza insuficiente. Reiniciando temporizador.")
            estado_peligro_actual = None
            tiempo_inicio_peligro = None

    return {
        "postura_peligrosa": postura_peligrosa_detectada,
        "segundos": round(tiempo_transcurrido, 1),
        "alerta_enviada": alerta_enviada if postura_peligrosa_detectada else False,
        "umbral_confianza": UMBRAL_CONFIANZA,
        "tiempo_alerta_segundos": TIEMPO_ALERTA_SEGUNDOS,
    }


def reiniciar_reglas():
    global estado_peligro_actual, tiempo_inicio_peligro, alerta_enviada
    estado_peligro_actual = None
    tiempo_inicio_peligro = None
    alerta_enviada = False


def disparar_alerta_medica(postura):
    # Función para ejecutar la alerta externa
    print(f"\n¡EMERGENCIA! Paciente inmovilizado por {TIEMPO_ALERTA_SEGUNDOS} segundos en: {postura}")
    print("Capturando coordenadas GPS y haciendo petición POST a la API (WhatsApp/Ambulancia)...")

if __name__ == "__main__":
    print("Inicia la aplicación completa ejecutando: python app.py")