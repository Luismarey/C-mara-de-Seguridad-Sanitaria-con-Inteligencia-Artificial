import json
import math
import mimetypes
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlsplit

ROOT = Path(__file__).resolve().parent
MODEL_DIR = ROOT / "Fallpose-model"
sys.path.insert(0, str(MODEL_DIR))
from IA_Rules import evaluar_predicciones, reiniciar_reglas


class CamaraSanitariaHandler(BaseHTTPRequestHandler):
    def _send_json(self, status, payload):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        requested_path = unquote(urlsplit(self.path).path)
        if requested_path == "/":
            file_path = ROOT / "index.html"
        elif requested_path.startswith("/Fallpose-model/"):
            relative_path = requested_path[len("/Fallpose-model/"):]
            file_path = (MODEL_DIR / relative_path).resolve()
            if MODEL_DIR not in file_path.parents:
                self.send_error(403, "Ruta no permitida")
                return
        else:
            self.send_error(404, "Recurso no encontrado")
            return

        if not file_path.is_file():
            self.send_error(404, "Recurso no encontrado")
            return

        content_type = mimetypes.guess_type(file_path.name)[0] or "application/octet-stream"
        body = file_path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        endpoint = urlsplit(self.path).path
        if endpoint == "/api/reset":
            reiniciar_reglas()
            self._send_json(200, {"ok": True})
            return

        if endpoint != "/api/evaluate":
            self._send_json(404, {"error": "Endpoint no encontrado"})
            return

        try:
            content_length = int(self.headers.get("Content-Length", "0"))
            if content_length < 1 or content_length > 65536:
                raise ValueError("Tamaño de solicitud inválido")
            payload = json.loads(self.rfile.read(content_length))
        except (ValueError, json.JSONDecodeError) as error:
            self._send_json(400, {"error": str(error)})
            return

        predictions = payload.get("predicciones") if isinstance(payload, dict) else None
        if not isinstance(predictions, dict) or not predictions:
            self._send_json(400, {"error": "Se esperaba un objeto 'predicciones' con probabilidades"})
            return

        for label, confidence in predictions.items():
            if (
                not isinstance(label, str)
                or isinstance(confidence, bool)
                or not isinstance(confidence, (int, float))
                or not math.isfinite(confidence)
                or confidence < 0
                or confidence > 1
            ):
                self._send_json(400, {"error": "Cada predicción debe tener una etiqueta y una probabilidad entre 0 y 1"})
                return

        continuous = payload.get("continuo", True)
        if not isinstance(continuous, bool):
            self._send_json(400, {"error": "'continuo' debe ser verdadero o falso"})
            return

        result = evaluar_predicciones(predictions, continuar_temporizador=continuous)
        self._send_json(200, {"predicciones": predictions, "reglas": result})

    def log_message(self, format_string, *args):
        print(f"{self.address_string()} - {format_string % args}")


if __name__ == "__main__":
    address = ("127.0.0.1", 8000)
    print(f"Cámara Sanitaria disponible en http://{address[0]}:{address[1]}")
    ThreadingHTTPServer(address, CamaraSanitariaHandler).serve_forever()
