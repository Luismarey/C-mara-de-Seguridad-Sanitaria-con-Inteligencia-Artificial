"""
metricas.py - Convierte resultados_evaluacion.csv (generado por evaluar.html)
en las tablas y figuras del articulo.

Uso:   python metricas.py resultados_evaluacion.csv
Salida (carpeta resultados/):
  tabla1_composicion.csv         imagenes de prueba por clase (y por origen)
  tabla3_metricas_por_clase.csv  precision, exhaustividad (recall), F1 por clase
  matriz_confusion.csv    matriz de confusion (conteos)
  tabla4_metricas_alerta.csv    sensibilidad, especificidad, precision, F1 de la ALERTA
  figura3_matriz_confusion.png
  extra_metricas_por_clase.png
  extra_confianza_boxplot.png
Requiere: pandas, numpy, matplotlib
"""
import sys, os, math
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

if len(sys.argv) < 2:
    sys.exit("Uso: python metricas.py resultados_evaluacion.csv")

df = pd.read_csv(sys.argv[1])
os.makedirs("resultados", exist_ok=True)

df = df[df["clase_predicha"] != "ERROR"].copy()
clases = [c for c in df["clase_real"].unique()]
orden = ["Normal", "Caida_Inmovilidad", "Cama_Normal", "Cama_Peligro"]
clases = [c for c in orden if c in clases] + [c for c in clases if c not in orden]
pred_cls = clases + [c for c in df["clase_predicha"].unique() if c not in clases]
df["prob_max"] = pd.to_numeric(df["prob_max"], errors="coerce")

def wilson(k, n, z=1.96):
    if n == 0:
        return (float("nan"), float("nan"))
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (max(0.0, c - h), min(1.0, c + h))

def pct(x):
    return "" if x is None or (isinstance(x, float) and math.isnan(x)) else f"{100*x:.1f}"

# ---- Tabla 1: composicion del conjunto de prueba ----
t1 = df.groupby("clase_real").size().reindex(clases).rename("imagenes_prueba").to_frame()
if df["origen"].notna().any():
    t1["origenes_distintos"] = df.groupby("clase_real")["origen"].nunique().reindex(clases)
t1.to_csv("resultados/tabla1_composicion.csv")

# ---- Matriz de confusion ----
cm = pd.crosstab(df["clase_real"], df["clase_predicha"]).reindex(index=clases, columns=pred_cls, fill_value=0)
cm.to_csv("resultados/matriz_confusion.csv")

# ---- Metricas por clase ----
filas = []
for c in clases:
    tp = int(((df.clase_real == c) & (df.clase_predicha == c)).sum())
    fp = int(((df.clase_real != c) & (df.clase_predicha == c)).sum())
    fn = int(((df.clase_real == c) & (df.clase_predicha != c)).sum())
    prec = tp / (tp + fp) if tp + fp else float("nan")
    rec = tp / (tp + fn) if tp + fn else float("nan")
    f1 = 2 * prec * rec / (prec + rec) if prec + rec and not math.isnan(prec + rec) else float("nan")
    lo, hi = wilson(tp, tp + fn)
    filas.append(dict(clase=c, n=tp + fn, VP=tp, FP=fp, FN=fn, precision_pct=pct(prec), exhaustividad_pct=pct(rec),
                      IC95_exhaustividad=f"{pct(lo)}-{pct(hi)}", F1_pct=pct(f1)))
t2 = pd.DataFrame(filas)
exactitud = (df.clase_real == df.clase_predicha).mean()
t2.to_csv("resultados/tabla3_metricas_por_clase.csv", index=False)

# ---- Metricas de la ALERTA (lo que importa para el sistema) ----
vp = int(((df.peligro_real == 1) & (df.alerta_modelo == 1)).sum())
fn = int(((df.peligro_real == 1) & (df.alerta_modelo == 0)).sum())
vn = int(((df.peligro_real == 0) & (df.alerta_modelo == 0)).sum())
fp = int(((df.peligro_real == 0) & (df.alerta_modelo == 1)).sum())
sens = vp / (vp + fn) if vp + fn else float("nan")
espe = vn / (vn + fp) if vn + fp else float("nan")
prec = vp / (vp + fp) if vp + fp else float("nan")
f1 = 2 * prec * sens / (prec + sens) if prec + sens and not math.isnan(prec + sens) else float("nan")
ls, hs = wilson(vp, vp + fn); le, he = wilson(vn, vn + fp)
t4 = pd.DataFrame([
    dict(metrica="Sensibilidad", valor_pct=pct(sens), IC95=f"{pct(ls)}-{pct(hs)}", detalle=f"{vp}/{vp+fn}"),
    dict(metrica="Especificidad", valor_pct=pct(espe), IC95=f"{pct(le)}-{pct(he)}", detalle=f"{vn}/{vn+fp}"),
    dict(metrica="Precision", valor_pct=pct(prec), IC95="", detalle=f"{vp}/{vp+fp}"),
    dict(metrica="F1", valor_pct=pct(f1), IC95="", detalle=""),
    dict(metrica="Exactitud global (4 clases)", valor_pct=pct(exactitud), IC95="", detalle=f"{int((df.clase_real==df.clase_predicha).sum())}/{len(df)}"),
])
t4.to_csv("resultados/tabla4_metricas_alerta.csv", index=False)

# ---- Figura 3: matriz de confusion ----
fig, ax = plt.subplots(figsize=(6.2, 5), dpi=200)
m = cm.values
ax.imshow(m, cmap="Blues")
ax.set_xticks(range(len(pred_cls))); ax.set_xticklabels(pred_cls, rotation=30, ha="right", fontsize=8)
ax.set_yticks(range(len(clases))); ax.set_yticklabels(clases, fontsize=8)
ax.set_xlabel("Clase predicha"); ax.set_ylabel("Clase real")
for i in range(m.shape[0]):
    for j in range(m.shape[1]):
        ax.text(j, i, int(m[i, j]), ha="center", va="center", fontsize=9, color="white" if m[i, j] > m.max() / 2 else "black")
fig.tight_layout(); fig.savefig("resultados/figura3_matriz_confusion.png", facecolor="white"); plt.close(fig)

# ---- Figura 4: precision / exhaustividad / F1 por clase ----
fig, ax = plt.subplots(figsize=(7, 3.8), dpi=200)
x = np.arange(len(clases)); w = 0.26
for k, (col, lab) in enumerate([("precision_pct", "Precisión"), ("exhaustividad_pct", "Exhaustividad"), ("F1_pct", "F1")]):
    vals = [float(v) if v != "" else 0 for v in t2[col]]
    ax.bar(x + (k - 1) * w, vals, w, label=lab)
ax.set_xticks(x); ax.set_xticklabels(clases, fontsize=8); ax.set_ylim(0, 105); ax.set_ylabel("%")
ax.legend(fontsize=8, ncol=3, loc="lower center"); ax.grid(axis="y", alpha=.3)
fig.tight_layout(); fig.savefig("resultados/extra_metricas_por_clase.png", facecolor="white"); plt.close(fig)

# ---- Figura 5: distribucion de la confianza por clase real ----
fig, ax = plt.subplots(figsize=(7, 3.8), dpi=200)
datos = [df.loc[df.clase_real == c, "prob_max"].dropna().values * 100 for c in clases]
ax.boxplot(datos, showfliers=True)
ax.set_xticks(range(1, len(clases) + 1)); ax.set_xticklabels(clases)
ax.axhline(95, color="red", ls="--", lw=1, label="Umbral de decisión (95 %)")
ax.set_ylabel("Confianza de la clase predicha (%)"); ax.legend(fontsize=8, loc="lower right"); ax.grid(axis="y", alpha=.3)
plt.setp(ax.get_xticklabels(), fontsize=8)
fig.tight_layout(); fig.savefig("resultados/extra_confianza_boxplot.png", facecolor="white"); plt.close(fig)

print(t1.to_string()); print(); print(t2.to_string(index=False)); print(); print(t4.to_string(index=False))
print("\nArchivos en la carpeta 'resultados/'.")